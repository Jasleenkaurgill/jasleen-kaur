package com.examples.countdownapp

import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.Chronometer
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var chronometer: Chronometer
    lateinit var startBtn: Button
    lateinit var pauseBtn: Button
    lateinit var resetBtn: Button
    lateinit var plus1Btn: Button
    lateinit var plus2Btn: Button
    lateinit var plus5Btn: Button
    lateinit var plus10Btn: Button
    var running = false
    var offset: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chronometer = findViewById(R.id.chronometer)
        startBtn = findViewById(R.id.start_btn)
        pauseBtn = findViewById(R.id.pause_btn)
        resetBtn = findViewById(R.id.reset_btn)
        plus1Btn = findViewById(R.id.plus_1_btn)
        plus2Btn = findViewById(R.id.plus_2_btn)
        plus5Btn = findViewById(R.id.plus_5_btn)
        plus10Btn = findViewById(R.id.plus_10_btn)

        chronometer.setOnChronometerTickListener {
            var currentOffset = SystemClock.elapsedRealtime() - chronometer.base
            if (currentOffset >= 0L) {
                chronometer.stop()
                offset = 0
            }
        }

        startBtn.setOnClickListener {
            if (!running) {
                setBaseTime()
                chronometer.start()
                running = true
            }
        }

        pauseBtn.setOnClickListener {
            if (running) {
                saveOffset()
                chronometer.stop()
                running = false
            }
        }

        resetBtn.setOnClickListener {
            offset = 0
            setBaseTime()
        }

        plus1Btn.setOnClickListener {
            offset += 1000
            setBaseTime()
        }

        plus2Btn.setOnClickListener {
            offset += 2000
            setBaseTime()
        }

        plus5Btn.setOnClickListener {
            offset += 5000
            setBaseTime()
        }

        plus10Btn.setOnClickListener {
            offset += 10000
            setBaseTime()
        }
    }

    fun setBaseTime() {
        chronometer.base = SystemClock.elapsedRealtime() + offset
    }

    fun saveOffset() {
        offset = SystemClock.elapsedRealtime() - chronometer.base
    }
}